package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{   
    @RequestMapping("/cipher")
    public String myHash(){
    	
    	String data = "My name is wha? My name is who? Chika chika Austin Frey";
    	String checksum = "";
  	  try {
            // creating the object of MessageDigest by using getInstance() method
            MessageDigest msgDig = MessageDigest.getInstance("SHA-256");
            
            // passing data to the MessageDigest object
            msgDig.update(data.getBytes());
            
            // Obtain the message digest hash value
            byte[] hashValue = msgDig.digest();
            
            //Convert the hash value into hex string format
            StringBuffer hexData = new StringBuffer();
            for (int i = 0; i < hashValue.length; i++) {  
                hexData.append(Integer.toHexString(0xFF & hashValue[i]));  
            }  
            
            checksum = hexData.toString();
        }
 
        catch (NoSuchAlgorithmException e) {
 
            System.out.println("Exception thrown : " + e);
        }
        catch (NullPointerException e) {
 
            System.out.println("Exception thrown : " + e);
        }
   
        return "<p>data:"+ data + "<br>SHA-256: Checksum Value: " + checksum + "</p>";
    }
}